<?php
header("Content-Type: application/json");

if (!isset($_GET['url'])) {
    echo json_encode(["error" => "No URL provided"]);
    exit;
}

$url = $_GET['url'];

// Fetch content using cURL instead of file_get_contents()
function fetchContent($url) {
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false); // Avoid SSL issues
    curl_setopt($ch, CURLOPT_USERAGENT, "Mozilla/5.0"); // Pretend to be a browser
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true); // Follow redirects
    $result = curl_exec($ch);
    curl_close($ch);
    return $result;
}

// Fetch Blogger post content
$pageContent = fetchContent($url);
if (!$pageContent) {
    echo json_encode(["error" => "Failed to fetch Blogger post"]);
    exit;
}

// Extract iframe source (URL)
preg_match('/<iframe[^>]+class="b-hbp-video b-uploaded"[^>]+src="([^"]+)"/', $pageContent, $iframeMatch);
if (!isset($iframeMatch[1])) {
    echo json_encode(["error" => "No video iframe found"]);
    exit;
}

$iframeSrc = $iframeMatch[1];

// Fetch the iframe content
$videoContent = fetchContent($iframeSrc);
if (!$videoContent) {
    echo json_encode(["error" => "Failed to fetch video iframe"]);
    exit;
}

// Extract JSON data from the iframe source
preg_match('/\[(.*?)\]/', $videoContent, $jsonMatch);
if (!isset($jsonMatch[1])) {
    echo json_encode(["error" => "No video URLs found"]);
    exit;
}

// Convert extracted JSON data into an array
$videoData = json_decode("[" . $jsonMatch[1] . "]", true);
if (!$videoData) {
    echo json_encode(["error" => "Invalid JSON data"]);
    exit;
}

// Prepare video URLs with resolution
$result = [];
foreach ($videoData as $video) {
    $quality = ($video['format_id'] == 18) ? '360p' : (($video['format_id'] == 22) ? '720p' : 'Unknown');
    $result[] = ["quality" => $quality, "url" => $video['play_url']];
}

// Return JSON response
echo json_encode($result);
?>
